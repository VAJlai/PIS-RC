<template>
    <div class="foot">
        <p>由大连理工大学新兴技术风险治理课题组与DLNU-ACM工作室共同制作</p>
        <br>
        <p>
           <span>联系电话：18842681469</span>&emsp;    
           <span>邮箱：<a href="http://gaizhendi@mail.dlut.edu.cn" style="color: white;">gaizhendi@mail.dlut.edu.cn</a></span>&emsp;    
           <span>地址：中国·辽宁省大连市甘井子区凌工路2号</span>   
        </p>
    </div>
</template>

<style scoped>
.foot {
    display: flex;
    height: 100px;
    text-align: center;
    justify-content: center;
    flex-direction: column;
    background-color: #1c2b40;
    margin-bottom: -100px;
}

p {
    color: #bbc0c6;
    font-size: small;
}
</style>

<script lang='ts'>
export default {
}

</script>