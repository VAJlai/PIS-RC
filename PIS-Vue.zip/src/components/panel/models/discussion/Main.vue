<template>
    <div>
        <Discuss></Discuss>
    </div>

</template>

<style scoped>

</style>

<script lang='ts'>
import { useRoute, } from 'vue-router'
import { reactive, toRefs } from 'vue'
import Discuss from "@/components/panel/models/discussion/Discuss.vue"


export default {

    setup() {
    }
}

</script>