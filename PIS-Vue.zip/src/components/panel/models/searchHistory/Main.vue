<template>
    <div>
        <h1>这是搜索历史</h1> 
        未确定功能形式，将会在后续更新中调整
    </div>
</template>

<style scoped>
</style>

<script lang='ts'>
export default {
    setup() {
        return {
        }
    }
}

</script>