import axios from 'axios';
import { showMessage } from "./status";   // 引入状态码文件
import { ElMessage } from 'element-plus'  // 引入el 提示框，这个项目里用什么组件库这里引什么

// 设置接口超时时间
axios.defaults.timeout = 60000;

axios.defaults.baseURL = "http://djaxl.cn:18080/"
// axios.defaults.baseURL = "http://82.157.45.25:18080/"

const localToken = localStorage.getItem('token') || ''

//http request 拦截器
axios.interceptors.request.use(
    config => {
        // 配置请求头
        config.headers = {
            'Content-Type': 'application/json;charset=UTF-8',        // 传参方式json
            'Authorization': "Bearer " + localToken,  // 这里自定义配置，这里传的是token
        };
        return config;
    },
    error => {
        return Promise.reject(error);
    }
);

//http response 拦截器
axios.interceptors.response.use(
    response => {
        return response;
    },
    error => {
        const { response } = error;
        if (response) {
            // 请求已发出，但是不在2xx的范围
            showMessage(response.status);           // 传入响应码，匹配响应码对应信息
            return Promise.reject(response.data);
        } else {
            ElMessage.warning('网络连接异常,请稍后再试!');
        }
    }
);

// 封装 GET POST 请求并导出
export function request(url = '', params = {}, type = 'POST') {
    if (type == "upload" || type == "update") {
        return axios.defaults.baseURL + url
    }
    if (type == "download") {
        return axios({
            responseType: 'blob',
            method: "get",
            url: axios.defaults.baseURL + url
        })
    }
    //设置 url params type 的默认值
    return new Promise((resolve, reject) => {
        let promise
        if (type.toUpperCase() === 'GET') {
            promise = axios({
                url,
                params
            })
        } else if (type.toUpperCase() === 'POST') {
            promise = axios({
                method: 'POST',
                url,
                data: params
            })
        } else if (type.toUpperCase() === 'PUT') {
            promise = axios({
                method: 'PUT',
                url,
                data: params
            })
        } else if (type.toUpperCase() === 'DELETE') {
            promise = axios({
                method: 'DELETE',
                url,
            })
        }
        //处理返回
        promise.then(res => {
            resolve(res)
        }).catch(err => {
            reject(err)
        })
    })
}